# feathers-s3

_Manage S3 objects using presigned url_

---

## Documentation

Detailed documentation is available at the following [link](https://kalisio.github.io/feathers-ekosystem/pacakges/feathers-s3).

## License

Licensed under the [MIT license](LICENSE).

Copyright (c) 2026-present [Kalisio](https://kalisio.com)

<a href="https://kalisio.com">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://kalisio.github.io/kalisioscope/kalisio/kalisio-logo-dark.svg">
    <source media="(prefers-color-scheme: light)" srcset="https://kalisio.github.io/kalisioscope/kalisio/kalisio-logo-light.svg">
    <img alt="Kalisio" src="https://kalisio.github.io/kalisioscope/kalisio/kalisio-logo-light.svg" height="96">
  </picture>
</a>